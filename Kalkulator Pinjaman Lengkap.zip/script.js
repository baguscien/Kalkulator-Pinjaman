document.getElementById('calculate-btn').addEventListener('click', hitungKredit);

function hitungKredit() {
    const loanType = document.getElementById('loan-type').value;
    const jumlahPinjaman = parseFloat(document.getElementById('loan-amount').value);
    const sukuBunga = parseFloat(document.getElementById('interest-rate').value) / 12 / 100;
    const tenorPinjaman = parseInt(document.getElementById('loan-tenure').value);

    if (isNaN(jumlahPinjaman) || isNaN(sukuBunga) || isNaN(tenorPinjaman) || jumlahPinjaman <= 0 || sukuBunga <= 0 || tenorPinjaman <= 0) {
        alert('Silakan masukkan input yang valid');
        return;
    }

    const cicilan = (jumlahPinjaman * sukuBunga * Math.pow(1 + sukuBunga, tenorPinjaman)) / (Math.pow(1 + sukuBunga, tenorPinjaman) - 1);
    const totalPembayaran = cicilan * tenorPinjaman;
    const totalBunga = totalPembayaran - jumlahPinjaman;

    document.getElementById('emi').textContent = cicilan.toFixed(2);
    document.getElementById('total-interest').textContent = totalBunga.toFixed(2);
    document.getElementById('total-payment').textContent = totalPembayaran.toFixed(2);

    generateAmortizationSchedule(jumlahPinjaman, sukuBunga, cicilan, tenorPinjaman);
}

function generateAmortizationSchedule(principal, monthlyRate, emi, tenure) {
    const scheduleTable = document.querySelector('#schedule-table tbody');
    scheduleTable.innerHTML = '';

    let remainingBalance = principal;

    for (let i = 1; i <= tenure; i++) {
        const interestPayment = remainingBalance * monthlyRate;
        const principalPayment = emi - interestPayment;
        remainingBalance -= principalPayment;

        const row = `
            <tr>
                <td>${i}</td>
                <td>${emi.toFixed(2)}</td>
                <td>${interestPayment.toFixed(2)}</td>
                <td>${principalPayment.toFixed(2)}</td>
                <td>${remainingBalance.toFixed(2)}</td>
            </tr>
        `;
        scheduleTable.insertAdjacentHTML('beforeend', row);
    }
}
